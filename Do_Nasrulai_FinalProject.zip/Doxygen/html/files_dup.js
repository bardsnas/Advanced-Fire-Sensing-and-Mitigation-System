var files_dup =
[
    [ "afsms.c", "afsms_8c.html", "afsms_8c" ],
    [ "afsms.h", "afsms_8h.html", "afsms_8h" ],
    [ "afsms_receiver.c", "afsms__receiver_8c.html", "afsms__receiver_8c" ],
    [ "afsms_receiver.h", "afsms__receiver_8h.html", "afsms__receiver_8h" ]
];