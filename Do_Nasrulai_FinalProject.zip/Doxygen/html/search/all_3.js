var searchData=
[
  ['dangerous_0',['DANGEROUS',['../afsms_8c.html#a608b8e697239da300545ecc90a7f1a56',1,'DANGEROUS:&#160;afsms.c'],['../afsms_8h.html#a608b8e697239da300545ecc90a7f1a56',1,'DANGEROUS:&#160;afsms.h']]],
  ['data_5fread_1',['Data_Read',['../afsms_8c.html#a69572928bb60bbcb3bbd19bec17d3294',1,'Data_Read(void *pvParameter):&#160;afsms.c'],['../afsms_8h.html#a69572928bb60bbcb3bbd19bec17d3294',1,'Data_Read(void *pvParameter):&#160;afsms.c']]],
  ['data_5fread_5fhandle_2',['Data_Read_Handle',['../afsms_8c.html#a3dd70313eb2a86d0018a68215fb11de7',1,'Data_Read_Handle:&#160;afsms.c'],['../afsms_8h.html#a3dd70313eb2a86d0018a68215fb11de7',1,'Data_Read_Handle:&#160;afsms.c']]],
  ['dataqueue_3',['dataQueue',['../afsms_8c.html#a2820736c7f6f9a3082102f0acd2cbac1',1,'dataQueue:&#160;afsms.c'],['../afsms_8h.html#a2820736c7f6f9a3082102f0acd2cbac1',1,'dataQueue:&#160;afsms.c']]],
  ['datareceived_4',['dataReceived',['../afsms__receiver_8c.html#a9550b9b8e9e8a87d8cf555007b9ee95a',1,'dataReceived(const esp_now_recv_info_t *esp_now_info, const uint8_t *incomingData, int len):&#160;afsms_receiver.c'],['../afsms__receiver_8h.html#a9550b9b8e9e8a87d8cf555007b9ee95a',1,'dataReceived(const esp_now_recv_info_t *esp_now_info, const uint8_t *incomingData, int len):&#160;afsms_receiver.c']]]
];
