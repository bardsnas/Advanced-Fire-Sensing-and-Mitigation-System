var searchData=
[
  ['ondatasent_0',['OnDataSent',['../afsms_8c.html#a1ec6b84c5d1247e1390758d6df12d0dc',1,'OnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status):&#160;afsms.c'],['../afsms_8h.html#a1ec6b84c5d1247e1390758d6df12d0dc',1,'OnDataSent(const uint8_t *mac_addr, esp_now_send_status_t status):&#160;afsms.c']]]
];
