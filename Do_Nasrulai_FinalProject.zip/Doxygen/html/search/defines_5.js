var searchData=
[
  ['scl_0',['SCL',['../afsms_8c.html#ab5ffc4751921608954bb7a5687566b2d',1,'SCL:&#160;afsms.c'],['../afsms_8h.html#ab5ffc4751921608954bb7a5687566b2d',1,'SCL:&#160;afsms.h']]],
  ['sda_1',['SDA',['../afsms_8c.html#a6890442e1cc24a0d61597a13576b8727',1,'SDA:&#160;afsms.c'],['../afsms_8h.html#a6890442e1cc24a0d61597a13576b8727',1,'SDA:&#160;afsms.h']]]
];
