var searchData=
[
  ['data_5fread_0',['Data_Read',['../afsms_8c.html#a69572928bb60bbcb3bbd19bec17d3294',1,'Data_Read(void *pvParameter):&#160;afsms.c'],['../afsms_8h.html#a69572928bb60bbcb3bbd19bec17d3294',1,'Data_Read(void *pvParameter):&#160;afsms.c']]],
  ['datareceived_1',['dataReceived',['../afsms__receiver_8c.html#a9550b9b8e9e8a87d8cf555007b9ee95a',1,'dataReceived(const esp_now_recv_info_t *esp_now_info, const uint8_t *incomingData, int len):&#160;afsms_receiver.c'],['../afsms__receiver_8h.html#a9550b9b8e9e8a87d8cf555007b9ee95a',1,'dataReceived(const esp_now_recv_info_t *esp_now_info, const uint8_t *incomingData, int len):&#160;afsms_receiver.c']]]
];
