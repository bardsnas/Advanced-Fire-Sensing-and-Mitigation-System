var searchData=
[
  ['setup_0',['setup',['../afsms_8c.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;afsms.c'],['../afsms__receiver_8c.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;afsms_receiver.c'],['../afsms__receiver_8h.html#a4fc01d736fe50cf5b977f755b675f11d',1,'setup():&#160;afsms.c']]]
];
