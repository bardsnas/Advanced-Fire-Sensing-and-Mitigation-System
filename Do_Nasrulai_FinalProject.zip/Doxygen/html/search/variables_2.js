var searchData=
[
  ['data_5fread_5fhandle_0',['Data_Read_Handle',['../afsms_8c.html#a3dd70313eb2a86d0018a68215fb11de7',1,'Data_Read_Handle:&#160;afsms.c'],['../afsms_8h.html#a3dd70313eb2a86d0018a68215fb11de7',1,'Data_Read_Handle:&#160;afsms.c']]],
  ['dataqueue_1',['dataQueue',['../afsms_8c.html#a2820736c7f6f9a3082102f0acd2cbac1',1,'dataQueue:&#160;afsms.c'],['../afsms_8h.html#a2820736c7f6f9a3082102f0acd2cbac1',1,'dataQueue:&#160;afsms.c']]]
];
